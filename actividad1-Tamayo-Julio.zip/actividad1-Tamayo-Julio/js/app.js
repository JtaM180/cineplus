$(document).ready(function () {

  // Spinner inicial
  $("#lista-peliculas").html("<p class='text-center'>Cargando...</p>");

  setTimeout(() => {

    $.ajax({
      url: "data/peliculas.json",
      method: "GET",
      dataType: "json",

      success: function (peliculas) {

        let html = "";

        peliculas.forEach(function (peli) {

          let hoy = new Date();
          let estreno = new Date(peli.estreno);

          let precio = "";
          let badge = "";
          let boton = "";

          // 🟡 PRÓXIMAMENTE (fecha futura)
          if (hoy < estreno) {
            precio = "Próximamente";
            badge = `<span class="badge bg-warning text-dark">Próximamente</span>`;
            boton = `<button class="btn btn-secondary" disabled>No disponible</button>`;
          }

          // 🔴 ESTRENO (menos de 7 días)
          else if ((hoy - estreno) <= (7 * 24 * 60 * 60 * 1000)) {
            precio = `$${peli.precios.estreno}`;
            badge = `<span class="badge bg-danger">Estreno</span>`;
            boton = `<a href="pages/detalle.html?id=${peli.id}" class="btn btn-primary">Ver más</a>`;
          }

          // 🔵 CARTELERA
          else {
            precio = `$${peli.precios.normal}`;
            badge = `<span class="badge bg-secondary">Cartelera</span>`;
            boton = `<a href="pages/detalle.html?id=${peli.id}" class="btn btn-primary">Ver más</a>`;
          }

          html += `
            <div class="col-md-4">
              <div class="card h-100 shadow">
                <img src="img/${peli.imagen}" class="card-img-top" alt="${peli.titulo}">
                <div class="card-body">
                  <h5 class="card-title">${peli.titulo}</h5>
                  ${badge}
                  <p class="card-text">${peli.sinopsis}</p>
                  <p><strong>Precio: ${precio}</strong></p>

                  ${boton}

                  <button class="btn btn-danger ver-trailer mt-2"
                    data-trailer="${peli.trailer}">
                    Ver tráiler
                  </button>

                </div>
              </div>
            </div>
          `;
        });

        // Animación
        $("#lista-peliculas").hide().html(html).fadeIn(1000);
      },

      error: function () {
        $("#lista-peliculas").html(`
          <div class="col-12">
            <div class="alert alert-danger text-center">
              Error al cargar películas
            </div>
          </div>
        `);
      }
    });

  }, 5000); // retraso obligatorio

});


// 🎬 EVENTO DEL TRÁILER
$(document).on("click", ".ver-trailer", function () {
  let url = $(this).data("trailer");
  $("#videoTrailer").attr("src", url);
  $("#modalTrailer").modal("show");
});

// 🧹 limpiar video al cerrar
$(document).on("hidden.bs.modal", "#modalTrailer", function () {
  $("#videoTrailer").attr("src", "");
});